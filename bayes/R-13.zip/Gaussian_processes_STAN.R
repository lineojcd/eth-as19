##Making inference for Gaussian processes with Stan
##Author: Fabio Sigrist

##Load required packages
library(RandomFields)
library("rstan")

##Simulation setting
n_obs=50##Number of observations
n_pred=100##Number of points on regular grid (used for making predictions)
N=n_pred+n_obs##Total number of points (used below for stan)
set.seed(1)
##Locations where data is observed
x_obs <- c(runif(n_obs/2,max=0.4),runif(n_obs/2,min=0.6))##With are where there is no data
##Locations on a regular grid where predictions of the process should be made
x_pred <- seq(from=0, to=1, length=n_pred)
x=c(x_pred,x_obs)

##Choice of covariance function and parameters for Gaussian process
sigmaP_sq=1##marginal variance of latent process z
rho=0.1##range parameter of latent process z
nu=1.5##smoothness of latent process z. This must be either 0.5, 1.5 or 2.5 in order that it can be used in the current Stan implementation
sigmaN_sq=0.2##error variance (nugget effect)
##Define model
modelP <- RMmatern(var=sigmaP_sq, scale=rho, nu=nu) 
modelN <- RMnugget(var=sigmaN_sq) 

##Simulate latent Gaussian process and add observation noise
RFoptions(seed=2)##set seed
z <- RFsimulate(modelP, x=x)@data$variable1
eps <- RFsimulate(modelN, x=x)@data$variable1
y=z+eps ##Observed process y is the some of the latent Gaussian process z and an observation error (nugget effect) eps
z_pred=z[1:n_pred]
y_obs=y[(n_pred+1):(n_pred+n_obs)]

##Plot data
library(RColorBrewer)
cols=brewer.pal(n = 4, name = "Set1")

legend=c("True Z","Observed data")
p=ggplot(data.frame(x=x_pred,z=z_pred,Legend=rep(legend[1],length(x_pred))),
         aes(x,z,colour=Legend))+geom_line(size=1.25)+
        geom_point(data=data.frame(x=x_obs,y=y_obs,Legend=rep(legend[2],length(x_obs))),
                   aes(x=x,y=y,colour=Legend),size=2)+
        scale_color_manual(values=cols[c(2,3)],breaks=legend,
                           guide=guide_legend(title=NULL,override.aes=list(linetype=c("solid","blank"),
                                                                           shape=c(NA, 16))))+
        scale_y_continuous(name="")+ theme(legend.position="top")
p

############################################
## 1. Sample from posterior of parameters ##
############################################

##Session -> Set Working Directory -> To Source File Location
GP_fit <- stan(file="GP.stan",data=c("n_obs","x_obs","y_obs","nu"),
               iter=500,chains=1,warmup=100,seed=2)##For illustration, use a low number of samples (in order to save time)
##Show summary measures
print(GP_fit, pars = c("rho", "sigmaP_sq", "sigmaN_sq"))
##Show univariate posterior densities
plot(GP_fit, pars = c("rho", "sigmaP_sq", "sigmaN_sq"))
##Bivariate posteriors
pairs(GP_fit, pars = c("rho", "sigmaP_sq","sigmaN_sq"))
##Trace plots
parsim <- extract(GP_fit)
par(mfrow=c(2,1),mar=c(1,4,1,1))
plot(parsim$rho,type="l",ylab="rho")
plot(parsim$sigmaP,type="l",ylab="sigma_z")


#######################################################################
## 2. Sample from both the posterior of the hyperparameters and      ##
##    the posterior of the latent process Z at observation locations ##
#######################################################################

GP_fit_latent <- stan(file="GP_latent.stan",data=c("n_obs","x_obs","y_obs","nu"),
                      iter=500,chains=1,warmup=100,seed=2)##For illustration, use a low number of samples (in order to save time)
# print(GP_fit_latent, pars = c("rho", "sigmaP_sq", "sigmaN_sq"))
# plot(GP_fit_latent, pars = c("rho", "sigmaP_sq", "sigmaN_sq"))

##Calculate posterior summaries (mean and credible interval)
z_sim <- extract(GP_fit_latent, pars = c("z"))$z
z_pmean=apply(z_sim,2,mean)
z_pquant=apply(z_sim,2,quantile,probs=c(0.025,0.975))

##Plot results
legend=c("True Z","Observed data","Posterior mean & credible interval for Z")
p=ggplot(data.frame(x=x_pred,z=z_pred,Legend=rep(legend[1],length(x_pred))),
         aes(x,z,colour=Legend))+geom_line(size=1.25)+
  geom_point(data=data.frame(x=x_obs,y=y_obs,Legend=rep(legend[2],length(x_obs))),
             aes(x=x,y=y,colour=Legend),size=2)+
  geom_errorbar(data=data.frame(x=x_obs,ymin=z_pquant[1,],ymax=z_pquant[2,],y=z_pmean,Legend=rep(legend[3],length(x_obs))),
                mapping=aes(x=x,ymin=ymin,ymax=ymax,colour=Legend,y=y), width=.05)+
  geom_point(data=data.frame(x=x_obs,y=z_pmean,Legend=rep(legend[3],length(x_obs))),
             aes(x=x,y=y,colour=Legend),size=2)+
  scale_color_manual(values=cols[c(2,1,3)],breaks=legend,
                     guide=guide_legend(title=NULL,override.aes=list(linetype=c("solid","blank","solid"),shape=c(NA,16,16))))+
  scale_y_continuous(name="")+ theme(legend.position="top")
p

################################################################
## 3. Sample from the postrior predictive distribution of the ##
##    latent process Z at locations where no data is observed ##
################################################################

GP_post_pred <- stan(file="GP_pred.stan",data=c("n_obs","x_obs","y_obs","n_pred","x_pred","nu"),
                    iter=500,chains=1,warmup=100,seed=2)##For illustration, use a low number of samples (in order to save time)
# print(GP_post_pred, pars = c("rho", "sigmaP_sq", "sigmaN_sq"))
# plot(GP_post_pred, pars = c("rho", "sigmaP_sq", "sigmaN_sq"))

##Calculate posterior summaries (mean and credible interval)
z_sim <- extract(GP_post_pred, pars = c("z_post_pred"))$z_post_pred
z_pmean=apply(z_sim,2,mean)
z_pquant=apply(z_sim,2,quantile,probs=c(0.025,0.975))
##Plot results
legend=c("True Z","Observed data","Posterior mean & credible interval for Z","Samples from PPD of Z")
p=ggplot(data.frame(x=x_pred,z=z_pred,Legend=rep(legend[1],length(x_pred))),
         aes(x,z,colour=Legend))+geom_line(size=1.25,linetype="solid")+
  geom_point(data=data.frame(x=x_obs,y=y_obs,Legend=rep(legend[2],length(x_obs))),
             aes(x=x,y=y,colour=Legend),size=2)+
  geom_line(data=data.frame(x=x_pred,y=z_pmean,Legend=rep(legend[3],length(x_obs))),
             aes(x=x,y=y,colour=Legend),size=1.25)+
  geom_line(data=data.frame(x=x_pred,y=z_sim[1,],Legend=rep(legend[4],length(x_obs))),
            aes(x=x,y=y,colour=Legend),size=1,linetype="dashed")+
  geom_line(data=data.frame(x=x_pred,y=z_sim[2,],Legend=rep(legend[4],length(x_obs))),
            aes(x=x,y=y,colour=Legend),size=1,linetype="dashed")+
  geom_ribbon(data=data.frame(x=x_pred,ymin=z_pquant[1,],ymax=z_pquant[2,],y=z_pmean,Legend=rep(legend[3],length(x_pred))),
              aes(x=x,ymin=ymin,ymax=ymax,y=y),alpha=0.2,color=NA)+
  scale_color_manual(values=cols[c(2,1,1,3)],breaks=legend,
                     guide=guide_legend(title=NULL,override.aes=list(linetype=c("solid","blank","solid","dashed"),
                                                                     shape=c(NA,16,NA,NA),
                                                                     size=c(1.25,2,1.25,1),fill=NA)))+
  scale_y_continuous(name="")+ theme(legend.position="top")
p

##Plot prediction uncertainty (width of credible interval)
ggplot(data.frame(x=x_pred,z=(z_pquant[2,]-z_pquant[1,]),Legend=rep("Width of credible interval",length(x_pred))),
       aes(x,z,colour=Legend))+geom_line(size=1.25)+scale_color_manual(values=cols[1],
                     guide=guide_legend(title=NULL))+scale_y_continuous(name="")+ theme(legend.position="top")

