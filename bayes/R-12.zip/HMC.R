#####################
## 1. HMC in RStan ##
#####################

## See https://github.com/stan-dev/rstan/wiki/RStan-Getting-Started#prerequisites 
## for information about how to install RStan

# install.packages("rstan", repos = "https://cloud.r-project.org/", dependencies=TRUE)
# install.packages("StanHeaders")
library("rstan")

##read data
##Session -> Set Working Directory -> To Source File Location
schools <- read.csv("schools.csv", header=TRUE)
schools
I <- nrow(schools)
y <- schools$estimate
sigma <- schools$sd

##Define model in STAN notation in file schools.stan
##Run HMC with 1 chains and N=2000 iterations after a burn-in of 500
schools_fit <- stan(file="schools.stan",data=c("I","y","sigma"),
                    iter=2500,chains=1,warmup=1000, control = list(adapt_delta = 0.99))
##Show summary measures
print(schools_fit)
##Show univariate posterio densities
plot(schools_fit, pars = c("mu", "tau","theta[1]","theta[2]","theta[3]"))
##Inspect bivariate posterior of mu, tau, and eta_1
pairs(schools_fit, pars = c("mu", "tau","theta[1]"))

##Manually extract simulated values in order to monitor convergence, 
##inspect posterior distributions, and run calculations with samples from posterior
schools_sim <- extract(schools_fit)
par(mfrow=c(2,1))
##Show trace plots
plot(schools_sim$mu,type="l")
plot(schools_sim$tau,type="l")
##Show acf 
acf(schools_sim$mu)
acf(schools_sim$tau)
## Compute the posterior probability that the effect is larger in school A than in school C:
mean(schools_sim$theta[,1] > schools_sim$theta[,3])


######################
## 2. HMC "by hand" ##
######################

## Hamiltonian MC for bivariate normal distribution
rho=0.98##0.98
neg.log.pi=function(x,Si) return(0.5*t(x)%*%Si%*%x)##Si: inverse covariance matrix
grad.neg.log.pi=function(x,Si) return(Si%*%x)
N=1000
##Parameters for leap frog discretization
##epsilon=step size, L=number of steps (T=epsilon*L)
epsilon=0.25
L=10##try:1, 5, 10


S=matrix(c(1,rho,rho,1),ncol=2)
Si=solve(S)
prop_rwm=sim_rwm=matrix(NA,nrow=2,ncol=N+1)
sv=c(0,0)##Deterministic initial value
prop_rwm[,1]=sim_rwm[,1]=sv

acc=0##number of accepted proposals
for(i in 1:N){
  current_x=sim_rwm[,i]
  x = current_x
  u = rnorm(length(x),0,1)  # independent standard normal variates
  
  ##Use the leapfrog method so generate proposals
  current_u = u
  # Make a half step for momentum at the beginning
  u = u - epsilon * grad.neg.log.pi(x,Si=Si) / 2
  # Alternate full steps for position and momentum
  for (j in 1:L){
    # Make a full step for the position
    x = x + epsilon * u
    # Make a full step for the momentum, except at end of trajectory
    if (j!=L) u = u - epsilon * grad.neg.log.pi(x,Si=Si)
  }
  # Make a half step for momentum at the end.
  u = u - epsilon * grad.neg.log.pi(x,Si=Si) / 2
  current_H= neg.log.pi(current_x,Si=Si)+ sum(current_u^2) / 2
  proposed_H = neg.log.pi(x,Si=Si)+ sum(u^2) / 2
  prop_rwm[,i+1]=x
  if (runif(1) < exp(current_H-proposed_H)){
    sim_rwm[,i+1]=x
    acc=acc+1
  }else{
    sim_rwm[,i+1]=sim_rwm[,i]
  }
}

##Trace plot and ACF
par(mfrow=c(2,1))
plot(sim_rwm[1,],type="l")
acf(sim_rwm[1,])

##Show first samples
n=20
xlim=c(min(c(sim_rwm[1,1:(n+1)],prop_rwm[1,2:(n+1)])),max(c(sim_rwm[1,1:(n+1)],prop_rwm[1,2:(n+1)])))
ylim=c(min(c(sim_rwm[2,1:(n+1)],prop_rwm[2,2:(n+1)])),max(c(sim_rwm[2,1:(n+1)],prop_rwm[2,2:(n+1)])))
par(mfrow=c(1,1))
plot(sim_rwm[1,1:(n+1)],sim_rwm[2,1:(n+1)],xlim=xlim,ylim=ylim)
arrows(sim_rwm[1,1:n],sim_rwm[2,1:n],prop_rwm[1,2:(n+1)],prop_rwm[2,2:(n+1)],col=4)

##Check marginal normality
plot(sim_rwm[1,],sim_rwm[2,])
qqnorm(sim_rwm[1,])
qqline(sim_rwm[1,])
qqnorm(sim_rwm[2,])
qqline(sim_rwm[2,])
